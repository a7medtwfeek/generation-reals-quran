# 🎬 فلترة فيديوهات Pexels - محتوى إسلامي فقط

## 📋 الوصف

هذا السكريبت يستخدم **Google Gemini AI Vision** لفلترة الفيديوهات من Pexels تلقائياً، ويضمن أن الفيديوهات:

### ✅ معايير القبول:
- ✓ **مناظر طبيعية فقط** (جبال، بحار، غيوم، شلالات، إلخ)
- ✓ **مساجد إسلامية** (عمارة إسلامية)
- ✓ **سماء ونجوم** (غروب، شروق، درب التبانة)
- ✓ **متوافق مع الشريعة الإسلامية**

### ❌ معايير الرفض:
- ✗ **بدون أشخاص** (حتى لو ظهور جزئي)
- ✗ **بدون حيوانات** (طيور، أسماك، حشرات، إلخ)
- ✗ **بدون محتوى مخالف للشريعة**

---

## 🚀 التثبيت

### 1. تثبيت المكتبات المطلوبة:

```bash
pip install -r requirements.txt
```

### 2. الحصول على Gemini API Key:

1. اذهب إلى: https://makersuite.google.com/app/apikey
2. سجل دخول بحساب Google
3. اضغط على **"Create API Key"**
4. انسخ المفتاح

### 3. تعيين API Key:

**في Windows (PowerShell):**
```powershell
$env:GEMINI_API_KEY="your-api-key-here"
```

**في Windows (Command Prompt):**
```cmd
set GEMINI_API_KEY=your-api-key-here
```

**في Linux/Mac:**
```bash
export GEMINI_API_KEY="your-api-key-here"
```

**أو** يمكنك إنشاء ملف `.env` في نفس المجلد:
```
GEMINI_API_KEY=your-api-key-here
```

---

## 📖 الاستخدام

### تشغيل السكريبت:

```bash
python filter_pexels_videos.py
```

### سيطلب منك:
```
📊 How many filtered videos to download? (default: 5):
```

أدخل العدد المطلوب (مثلاً: 10)

---

## 🔍 كيف يعمل؟

1. **البحث**: يبحث في Pexels عن كلمات مفتاحية محددة (مساجد، مناظر طبيعية)
2. **التحليل**: يستخرج إطار من كل فيديو ويحلله باستخدام Gemini AI
3. **الفلترة**: يرفض أي فيديو يحتوي على أشخاص أو حيوانات
4. **التحميل**: يحمل فقط الفيديوهات المقبولة إلى مجلد `backgrounds/`

---

## 📊 مثال على المخرجات:

```
🔍 Searching for: 'mosque architecture'
📦 Found 20 videos, filtering...

🔄 Attempt 1/15
   📹 Analyzing video ID: 12345...
   📊 Analysis: Beautiful mosque with golden dome at sunset
   👤 Humans: False | 🐾 Animals: False | ✓ Appropriate: True
   ✅ ACCEPTED - Category: mosque
   💾 Downloaded to: pexels_12345.mp4

✅ Success! Total downloaded: 1/5
```

---

## 🎯 الكلمات المفتاحية المستخدمة:

السكريبت يبحث عن:
- `mosque architecture` - عمارة المساجد
- `islamic mosque` - مساجد إسلامية
- `masjid` - مسجد
- `nature landscape` - مناظر طبيعية
- `mountain scenery` - مناظر جبلية
- `ocean waves` - أمواج البحر
- `clouds sky` - سماء وغيوم
- `sunset sky` - غروب الشمس
- `stars night sky` - سماء ليلية
- `forest nature` - غابات طبيعية
- `waterfall nature` - شلالات
- `desert landscape` - صحراء
- `northern lights` - الشفق القطبي
- `milky way stars` - درب التبانة

---

## ⚙️ التخصيص

### تعديل الكلمات المفتاحية:

افتح `filter_pexels_videos.py` وعدل القائمة `FILTERED_KEYWORDS`:

```python
FILTERED_KEYWORDS = [
    "your custom keyword 1",
    "your custom keyword 2",
    # ...
]
```

### تعديل معايير الفلترة:

في دالة `is_video_acceptable()` يمكنك تعديل المنطق:

```python
is_acceptable = not has_humans and not has_animals and is_appropriate
```

---

## 🛠️ متطلبات النظام:

- **Python 3.8+**
- **FFmpeg** (لاستخراج الإطارات من الفيديو)
  - Windows: حمل من https://ffmpeg.org/download.html
  - Linux: `sudo apt install ffmpeg`
  - Mac: `brew install ffmpeg`

---

## 📝 ملاحظات مهمة:

1. **السرعة**: كل فيديو يأخذ حوالي 10-20 ثانية للتحليل
2. **الدقة**: AI دقيق جداً في اكتشاف الأشخاص والحيوانات
3. **الحصة المجانية**: Gemini API له حصة مجانية محدودة شهرياً
4. **الإنترنت**: يحتاج اتصال إنترنت مستقر

---

## 🔧 استكشاف الأخطاء:

### خطأ: "GEMINI_API_KEY not set"
**الحل**: تأكد من تعيين المفتاح بشكل صحيح

### خطأ: "ffmpeg not found"
**الحل**: ثبت FFmpeg وتأكد أنه في PATH

### خطأ: "Could not extract frame"
**الحل**: تأكد من اتصال الإنترنت وأن FFmpeg يعمل

---

## 📞 الدعم

إذا واجهت أي مشاكل، تحقق من:
1. ✓ API Key صحيح
2. ✓ FFmpeg مثبت
3. ✓ اتصال إنترنت مستقر
4. ✓ المكتبات مثبتة بشكل صحيح

---

## 📄 الترخيص

هذا المشروع للاستخدام الشخصي والتعليمي.
الفيديوهات من Pexels مجانية للاستخدام التجاري.

---

**بالتوفيق! 🎉**
