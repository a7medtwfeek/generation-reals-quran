# ⚡ البدء السريع - فلترة فيديوهات Pexels

## 🎯 الطريقة الأسرع (بدون AI)

### خطوة واحدة فقط:

```bash
python simple_filter_videos.py
```

أدخل عدد الفيديوهات المطلوبة (مثلاً: `10`)

**✅ انتهى!** الفيديوهات في مجلد `backgrounds/`

---

## 🤖 الطريقة الأدق (مع AI)

### 3 خطوات:

#### 1. احصل على API Key مجاني:
https://makersuite.google.com/app/apikey

#### 2. عيّن المفتاح:
```powershell
$env:GEMINI_API_KEY="your-key-here"
```

#### 3. شغّل السكريبت:
```bash
python filter_pexels_videos.py
```

---

## 🔍 مراجعة الفيديوهات الموجودة

```bash
$env:GEMINI_API_KEY="your-key-here"
python review_videos.py
```

---

## 📦 التثبيت (مرة واحدة فقط)

```bash
pip install -r requirements.txt
```

---

## ❓ أي أداة تستخدم؟

| الحالة | الأداة |
|--------|--------|
| تريد سرعة | `simple_filter_videos.py` |
| تريد دقة 100% | `filter_pexels_videos.py` |
| تريد مراجعة موجود | `review_videos.py` |

---

**للتفاصيل الكاملة:** اقرأ `VIDEO_FILTER_GUIDE_AR.md`
