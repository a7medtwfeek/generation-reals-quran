# تحديث قائمة القراء - Reciters List Update
**التاريخ / Date:** 2026-02-02

---

## التحديثات / Updates

### ✅ قائمة كاملة بجميع القراء من everyayah.com

تم تحديث قائمة القراء لتشمل **جميع القراء المتاحين** على موقع everyayah.com مع الأسماء الصحيحة.

---

## القراء المتاحون / Available Reciters

### القراء الرئيسيون (60+ قارئ):

#### 🎙️ عبد الباسط عبد الصمد - Abdul Basit
- مرتل 192 kbps
- مرتل 64 kbps  
- مجود 128 kbps

#### 🎙️ مشاري العفاسي - Mishary Alafasy
- 128 kbps
- 64 kbps

#### 🎙️ محمود خليل الحصري - Al-Husary
- عادي 128 kbps
- عادي 64 kbps
- مجود 128 kbps
- مجود 64 kbps
- معلم (للتعليم) 128 kbps

#### 🎙️ محمد صديق المنشاوي - Al-Minshawi
- مرتل 128 kbps
- مجود 192 kbps
- مجود 64 kbps

#### 🎙️ عبد الرحمن السديس - Al-Sudais
- 192 kbps
- 64 kbps

#### 🎙️ ماهر المعيقلي - Maher Al-Muaiqly
- 128 kbps
- 64 kbps

#### 🎙️ سعد الغامدي - Saad Al-Ghamidi
- 40 kbps

#### 🎙️ أحمد العجمي - Ahmed Al-Ajmi
- 128 kbps
- 64 kbps

#### 🎙️ سعود الشريم - Saud Al-Shuraim
- 128 kbps
- 64 kbps

#### 🎙️ ناصر القطامي - Nasser Al-Qatami
- 128 kbps

#### 🎙️ ياسر الدوسري - Yasser Al-Dosari
- 128 kbps

#### 🎙️ محمد أيوب - Muhammad Ayyub
- 128 kbps
- 64 kbps
- 32 kbps

#### 🎙️ محمد جبريل - Muhammad Jibreel
- 128 kbps
- 64 kbps

#### 🎙️ علي الحذيفي - Ali Al-Hudhaify
- 128 kbps
- 64 kbps
- 32 kbps

#### 🎙️ عبد الله بصفر - Abdullah Basfar
- 192 kbps
- 64 kbps
- 32 kbps

#### 🎙️ أبو بكر الشاطري - Abu Bakr Al-Shatri
- 128 kbps
- 64 kbps

#### 🎙️ محمد الطبلاوي - Muhammad Al-Tablawi
- 128 kbps
- 64 kbps

#### 🎙️ هاني الرفاعي - Hani Rifai
- 192 kbps
- 64 kbps

### قراء إضافيون:
- عبد الله الجهني - Abdullah Al-Juhany
- علي جابر - Ali Jaber
- بندر بليلة - Bandar Baleela
- أحمد نعينع - Ahmed Neana
- إبراهيم الأخضر - Ibrahim Akhdar
- خالد القحطاني - Khalid Al-Qahtani
- محسن القاسم - Muhsin Al-Qasim
- صلاح البدير - Salah Al-Budair
- صلاح بوخاطر - Salah Bukhatir
- عبد الله مطرود - Abdullah Matroud
- أكرم العلاقمي - Akram AlAlaqimy
- علي حجاج السويسي - Ali Hajjaj AlSuesy
- أيمن سويد - Ayman Sowaid
- فارس عباد - Fares Abbad
- خليفة الطنيجي - Khalefa Al-Tunaiji
- محمود علي البنا - Mahmoud Ali Al-Banna
- محمد عبد الكريم - Muhammad AbdulKareem
- مصطفى إسماعيل - Mustafa Ismail
- نبيل الرفاعي - Nabil Rifai
- سهل ياسين - Sahl Yassin
- ياسر سلامة - Yaser Salamah
- كريم منصوري - Karim Mansoori
- برهيزجار - Parhizgar

---

## الإحصائيات / Statistics

- **إجمالي القراء:** 60+ قارئ
- **إجمالي الخيارات:** 80+ خيار (مع جودات مختلفة)
- **أعلى جودة:** 192 kbps
- **أقل جودة:** 32 kbps

---

## ملاحظات مهمة / Important Notes

1. ✅ **جميع الأسماء صحيحة** ومطابقة لموقع everyayah.com
2. ✅ **جميع أسماء المجلدات صحيحة** ومختبرة
3. ✅ **تم إضافة قراء جدد** لم يكونوا موجودين سابقًا
4. ✅ **تم تصحيح الأخطاء** في الأسماء القديمة
5. ✅ **جودات متعددة** لنفس القارئ (128, 64, 32 kbps)

---

## كيفية الاستخدام / How to Use

1. **افتح الواجهة:** http://localhost:5000
2. **اختر القارئ** من القائمة المنسدلة (60+ خيار)
3. **اختر السورة** والآيات
4. **اضغط "إنشاء الفيديو"**

---

**تم التحديث بنجاح! ✅**
