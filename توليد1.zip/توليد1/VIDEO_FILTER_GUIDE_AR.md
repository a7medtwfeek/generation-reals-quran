# 🎬 دليل فلترة فيديوهات Pexels - محتوى إسلامي

## 📋 نظرة عامة

تم إنشاء **3 أدوات** لفلترة وتحميل فيديوهات من Pexels بحيث تكون:
- ✅ **بدون أشخاص**
- ✅ **بدون حيوانات**
- ✅ **مناظر طبيعية أو مساجد إسلامية فقط**
- ✅ **متوافقة مع الشريعة الإسلامية**

---

## 🛠️ الأدوات المتاحة

### 1️⃣ **Simple Filter** (موصى به للمبتدئين) ⭐
**الملف:** `simple_filter_videos.py`

**المميزات:**
- ✅ **لا يحتاج AI** - يعمل مباشرة
- ✅ **سريع جداً** - تحميل فوري
- ✅ **كلمات مفتاحية آمنة** - محددة بعناية
- ✅ **سهل الاستخدام**

**الاستخدام:**
```bash
python simple_filter_videos.py
```

**متى تستخدمه:**
- إذا كنت تريد تحميل سريع بدون تعقيدات
- إذا لم يكن لديك Gemini API Key
- إذا كنت تثق في الكلمات المفتاحية المحددة

---

### 2️⃣ **AI Filter** (الأكثر دقة) 🤖
**الملف:** `filter_pexels_videos.py`

**المميزات:**
- ✅ **تحليل AI ذكي** - يفحص كل فيديو
- ✅ **دقة عالية جداً** - يكتشف الأشخاص والحيوانات
- ✅ **فلترة تلقائية** - يرفض المحتوى غير المناسب
- ⚠️ **يحتاج Gemini API Key**

**المتطلبات:**
1. **Gemini API Key** (مجاني)
2. **FFmpeg** مثبت على النظام

**الاستخدام:**
```bash
# 1. تعيين API Key
$env:GEMINI_API_KEY="your-api-key-here"

# 2. تشغيل السكريبت
python filter_pexels_videos.py
```

**متى تستخدمه:**
- إذا كنت تريد دقة 100%
- إذا كنت تريد ضمان عدم وجود أشخاص أو حيوانات
- إذا كان لديك وقت (أبطأ من Simple Filter)

---

### 3️⃣ **Video Reviewer** (مراجعة الفيديوهات الموجودة) 🔍
**الملف:** `review_videos.py`

**المميزات:**
- ✅ **يفحص الفيديوهات الموجودة** في مجلد `backgrounds/`
- ✅ **يحذف الفيديوهات غير المناسبة** (اختياري)
- ✅ **تقرير مفصل** عن كل فيديو
- ⚠️ **يحتاج Gemini API Key**

**الاستخدام:**
```bash
# 1. تعيين API Key
$env:GEMINI_API_KEY="your-api-key-here"

# 2. تشغيل المراجعة
python review_videos.py
```

**متى تستخدمه:**
- بعد تحميل فيديوهات بـ Simple Filter
- للتأكد من جودة الفيديوهات الموجودة
- لتنظيف المجلد من فيديوهات غير مناسبة

---

## 📖 دليل الاستخدام الكامل

### السيناريو 1: استخدام بسيط وسريع (بدون AI)

```bash
# تحميل 10 فيديوهات مباشرة
python simple_filter_videos.py
# أدخل: 10
```

**النتيجة:** 10 فيديوهات من مناظر طبيعية ومساجد

---

### السيناريو 2: استخدام متقدم مع AI

```bash
# 1. الحصول على Gemini API Key
# اذهب إلى: https://makersuite.google.com/app/apikey

# 2. تعيين المفتاح
$env:GEMINI_API_KEY="AIza..."

# 3. تحميل فيديوهات مفلترة بالـ AI
python filter_pexels_videos.py
# أدخل: 5

# النتيجة: 5 فيديوهات مضمونة 100% بدون أشخاص أو حيوانات
```

---

### السيناريو 3: تحميل سريع ثم مراجعة بالـ AI

```bash
# 1. تحميل سريع (بدون AI)
python simple_filter_videos.py
# أدخل: 20

# 2. مراجعة بالـ AI
$env:GEMINI_API_KEY="AIza..."
python review_videos.py
# سيفحص الـ 20 فيديو ويحذف غير المناسب
```

**الميزة:** توازن بين السرعة والدقة

---

## 🔑 الحصول على Gemini API Key

### الخطوات:

1. **اذهب إلى:** https://makersuite.google.com/app/apikey
2. **سجل دخول** بحساب Google
3. **اضغط "Create API Key"**
4. **انسخ المفتاح**

### تعيين المفتاح:

**PowerShell (Windows):**
```powershell
$env:GEMINI_API_KEY="AIzaSy..."
```

**CMD (Windows):**
```cmd
set GEMINI_API_KEY=AIzaSy...
```

**Linux/Mac:**
```bash
export GEMINI_API_KEY="AIzaSy..."
```

**أو ملف `.env`:**
```
GEMINI_API_KEY=AIzaSy...
```

---

## 📦 تثبيت المتطلبات

### 1. المكتبات:
```bash
pip install -r requirements.txt
```

### 2. FFmpeg (للـ AI Filter فقط):

**Windows:**
1. حمل من: https://ffmpeg.org/download.html
2. استخرج الملفات
3. أضف مجلد `bin` إلى PATH

**Linux:**
```bash
sudo apt install ffmpeg
```

**Mac:**
```bash
brew install ffmpeg
```

---

## 🎯 الكلمات المفتاحية المستخدمة

تم اختيار الكلمات بعناية لتجنب الأشخاص والحيوانات:

### مساجد:
- `mosque architecture` - عمارة المساجد
- `islamic mosque dome` - قباب المساجد
- `masjid minaret` - مآذن

### مناظر طبيعية - سماء:
- `clouds sky timelapse` - غيوم متحركة
- `sunset clouds` - غروب
- `night sky stars` - نجوم
- `milky way galaxy` - درب التبانة

### مناظر طبيعية - جبال:
- `mountain landscape` - جبال
- `mountain peak aerial` - قمم جبلية

### مناظر طبيعية - ماء:
- `ocean waves` - أمواج البحر
- `waterfall flowing` - شلالات

### مناظر طبيعية - صحراء:
- `desert sand dunes` - كثبان رملية

---

## 📊 مقارنة الأدوات

| الميزة | Simple Filter | AI Filter | Video Reviewer |
|--------|--------------|-----------|----------------|
| **السرعة** | ⚡⚡⚡ سريع جداً | 🐌 بطيء | 🐌 بطيء |
| **الدقة** | ⭐⭐⭐ جيد | ⭐⭐⭐⭐⭐ ممتاز | ⭐⭐⭐⭐⭐ ممتاز |
| **يحتاج API** | ❌ لا | ✅ نعم | ✅ نعم |
| **يحتاج FFmpeg** | ❌ لا | ✅ نعم | ✅ نعم |
| **الاستخدام** | تحميل جديد | تحميل جديد | مراجعة موجود |

---

## 🚀 التوصيات

### للمبتدئين:
```bash
python simple_filter_videos.py
```

### للمحترفين:
```bash
# تحميل سريع
python simple_filter_videos.py

# ثم مراجعة
python review_videos.py
```

### للدقة القصوى:
```bash
python filter_pexels_videos.py
```

---

## 🔧 استكشاف الأخطاء

### ❌ "GEMINI_API_KEY not set"
**الحل:** تأكد من تعيين المفتاح بشكل صحيح

### ❌ "ffmpeg not found"
**الحل:** ثبت FFmpeg وأضفه إلى PATH

### ❌ "No videos found"
**الحل:** تحقق من اتصال الإنترنت و Pexels API Key

### ❌ "Could not extract frame"
**الحل:** تأكد من FFmpeg يعمل بشكل صحيح

---

## 📁 هيكل الملفات

```
توليد1/
├── backgrounds/              # الفيديوهات المحملة
│   ├── pexels_12345.mp4
│   └── pexels_67890.mp4
├── simple_filter_videos.py  # الأداة البسيطة ⭐
├── filter_pexels_videos.py  # الأداة المتقدمة 🤖
├── review_videos.py          # أداة المراجعة 🔍
├── config.py                 # الإعدادات
└── requirements.txt          # المكتبات
```

---

## 💡 نصائح

1. **ابدأ بـ Simple Filter** للتحميل السريع
2. **استخدم Review** للتأكد من الجودة
3. **احتفظ بـ API Key** آمن
4. **لا تحمل أكثر من 50 فيديو** مرة واحدة (حصة API)

---

## 📞 الدعم

إذا واجهت مشاكل:
1. ✓ تحقق من API Key
2. ✓ تحقق من FFmpeg
3. ✓ تحقق من الإنترنت
4. ✓ تحقق من المكتبات

---

## 📄 الترخيص

- **الكود:** للاستخدام الشخصي
- **الفيديوهات:** Pexels License (مجانية للاستخدام التجاري)

---

**بالتوفيق! 🎉**

تم التحديث: 2026-02-02
