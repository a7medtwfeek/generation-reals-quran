# دليل استكشاف الأخطاء السريع
# Quick Troubleshooting Guide

## ❌ مشكلة: "فشل في إنشاء الفيديو"

### الخطوة 1: تشغيل المُشخص

```bash
cd "c:\Users\Ahmed\Videos\توليد1"
python diagnose.py
```

سيختبر المُشخص:
- ✅ نسخة Python
- ✅ وجود FFmpeg
- ✅ المكتبات المثبتة
- ✅ الاتصال بالإنترنت
- ✅ هيكل الملفات
- ✅ واجهات APIs
- ✅ الخطوط العربية

### الخطوة 2: حل المشاكل الشائعة

#### مشكلة: FFmpeg NOT FOUND ❌

**الحل:**
1. حمّل FFmpeg:
   ```
   https://www.gyan.dev/ffmpeg/builds/
   ```

2. اختر "ffmpeg-release-full.7z"

3. فك الضغط إلى: `C:\ffmpeg`

4. أضف إلى PATH:
   - افتح "تحرير متغيرات بيئة النظام"
   - System Properties → Environment Variables
   - Path → Edit → New
   - أضف: `C:\ffmpeg\bin`
   - OK → OK

5. أعد تشغيل Command Prompt

6. تحقق:
   ```bash
   ffmpeg -version
   ```

#### مشكلة: مكتبة مفقودة ❌

**الحل:**
```bash
pip install -r requirements.txt
```

أو بشكل فردي:
```bash
pip install Flask requests Pillow
```

#### مشكلة: فشل الاتصال بالإنترنت ❌

**الحل:**
- تحقق من اتصال الإنترنت
- جرب إيقاف VPN إن وُجد
- تحقق من جدار الحماية (Firewall)

#### مشكلة: النص العربي لا يظهر صحيحاً ⚠️

**الحل:**
حمّل خطوط عربية:
- Amiri: https://fonts.google.com/specimen/Amiri
- أو استخدم خط النظام الافتراضي

---

## 🧪 اختبار بسيط

### اختبار توليد فيديو تجريبي:

```bash
python -c "from video_generator import VideoGenerator; g = VideoGenerator(); print('Generator OK' if g.check_ffmpeg() else 'FFmpeg Missing')"
```

### اختبار Quran API:

```bash
python -c "from quran_api import QuranAPI; api = QuranAPI(); verses = api.get_verse_text(1, 1, 1); print(verses[0]['text'] if verses else 'API Failed')"
```

### اختبار Pexels API:

```bash
python pexels_api.py
```

---

## 📋 قائمة التحقق الكاملة

قبل محاولة إنشاء فيديو، تأكد من:

- [ ] Python 3.8+ مثبت
- [ ] FFmpeg مثبت ومضاف للـ PATH
- [ ] جميع المكتبات مثبتة (requirements.txt)
- [ ] الاتصال بالإنترنت يعمل
- [ ] يمكن الوصول إلى everyayah.com
- [ ] يمكن الوصول إلى api.alquran.cloud
- [ ] يمكن الوصول إلى pexels.com
- [ ] المجلدات موجودة (temp/, output/, backgrounds/)

---

## 🔍 الأخطاء الشائعة ورسائلها

### "FileNotFoundError: FFmpeg"
→ FFmpeg غير مثبت أو غير مضاف للـ PATH

### "Failed to fetch verse texts"
→ مشكلة في الاتصال بـ api.alquran.cloud

### "Failed to download audio"
→ مشكلة في الاتصال بـ everyayah.com

### "Failed to download background"
→ مشكلة في Pexels API أو الاتصال

### "FFmpeg error: does not contain any stream"
→ ملف الخلفية تالف أو فارغ

### "TimeoutExpired"
→ العملية استغرقت وقتاً طويلاً جداً (>5 دقائق)

---

## 💡 نصائح للأداء الأفضل

1. **ابدأ بآيات قليلة**: جرب 1-3 آيات أولاً
2. **تحقق من سرعة الإنترنت**: سرعة جيدة = تحميل أسرع
3. **لا تغلق Terminal**: انتظر حتى ينتهي الإنشاء كاملاً
4. **انظر إلى سجلات الخادم**: لمعرفة أين تحدث المشكلة

---

## 🆘 للحصول على مساعدة إضافية

1. شغّل المُشخص:
   ```bash
   python diagnose.py
   ```

2. شغّل اختبار الفيديو مباشرة:
   ```bash
   python video_generator.py
   ```

3. راجع سجلات الخادم في Terminal حيث يعمل `python main.py`

4. راجع browser console (F12) للأخطاء في الواجهة

---

## ✅ إذا كل شيء يعمل

إذا مر المُشخص بنجاح ولكن ما زال الفيديو يفشل:

1. جرب إنشاء فيديو من Terminal مباشرة:
   ```bash
   python video_generator.py
   ```

2. تحقق من مساحة القرص المتاحة

3. تحقق من صلاحيات الكتابة في المجلدات

4. جرب تشغيل Terminal كـ Administrator

---

**تذكر**: راجع README.md للدليل الكامل!
